README Instructions : 


Note: You should have node installed on your computer.

1. Download this folder in your local PC 
2. Open command prompt inside the folder location("/fetch") and Enter "npm i"  
3. You will see "node modules" folder created inside "/fetch"
4. Run "node fetchFiles.js" to fetch the audio files in the uploads folder.


5. Upload the "uploads" folder in Audio-Recorder shared drive
	and run the GoogleRecognizer/AzureRecognizer Colab files(Run all cells).

